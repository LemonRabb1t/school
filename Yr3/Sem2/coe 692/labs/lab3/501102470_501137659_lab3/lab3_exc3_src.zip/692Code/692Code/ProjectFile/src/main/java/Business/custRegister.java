/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Persistence.Customer_CRUD;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author nini yang
 */
@WebServlet(name = "custRegister", urlPatterns = {"/custRegister"})

public class custRegister extends HttpServlet {

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // obtain user's info
        String username = (String) request.getParameter("username");
        String password = (String) request.getParameter("password");
        String fname = (String) request.getParameter("fname");
        String lname = (String) request.getParameter("lname");
        String adr1 = (String) request.getParameter("addressL1");
        String adr2 = null;
        // if add2 exists
        if (request.getParameter("address2") != null) {
            adr2 = (String) request.getParameter("addressL2");

        }

        // further imple
        String city = (String) request.getParameter("city");
        String prov = (String) request.getParameter("province");
        String country = (String) request.getParameter("Country");
        //

        String email = (String) request.getParameter("email");

        if (password != null) {
            request.getSession().setAttribute("username", username);

            // create User profile
            int newAccount = Customer_CRUD.write(2, fname, lname, adr1, email);
            int test = Customer_CRUD.write(2, "Nino", "Berr", "921 jackson road", "ninoberr@gmail.com");

            if (test > 0) { // if rows successfully written in
                RequestDispatcher rd = request.getRequestDispatcher("custRegister.jsp");
                rd.forward(request, response);
            } else {
                RequestDispatcher rd = request.getRequestDispatcher("custRegisterFAIL.jsp");
                rd.forward(request, response);
            }
        } else {
            RequestDispatcher rd = request.getRequestDispatcher("custRegisterFAIL.jsp");
            rd.forward(request, response);
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
