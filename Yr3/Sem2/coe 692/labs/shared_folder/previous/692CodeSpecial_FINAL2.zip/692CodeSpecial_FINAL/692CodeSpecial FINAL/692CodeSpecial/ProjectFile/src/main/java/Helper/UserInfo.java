/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author student
 */
public class UserInfo {

    private String fname, lname, adr, email, username, password;
    
    public UserInfo( String fname, String lname, String adr, String email, String username, String password) {

        this.fname = fname;
        this.lname = lname;
        this.adr = adr;
        this.email = email;
        this.username = username;
        this.password = password;
    }


    public String getFname() {
        return fname;
    }


    public String getLname() {
        return lname;
    }


    public String getAdr() {
        return adr;
    }


    public String getEmail() {
        return email;
    }


    public String getUsername() {
        return username;
    }


    public String getPassword() {
        return password;
    }
    
      private static Connection getCon() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/SCS", "root", "student");
            System.out.println("Connection established.");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
    
    public void write() {
        int rowsAdded = 0;
        Connection con = null;
        PreparedStatement ps= null;
        try {
            con = getCon();

            if (con != null) {

                String q = "INSERT INTO Customer (firstName, lastName, address, email, username, password) Values (?,?,?,?,?,?);";

                ps = con.prepareStatement(q);
                ps.setString(1, getFname());
                ps.setString(2, getLname());
                ps.setString(3, getAdr());
                ps.setString(4, getEmail());
                ps.setString(5, getUsername());
                ps.setString(6, getPassword());

                rowsAdded = ps.executeUpdate();
                
                if (rowsAdded > 0) {
                    System.out.println("Account created.");
                } else {
                    System.out.println("USER: Failed to save playlist information.");
                }
            } else {
                System.out.println("No connection");
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally{
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                System.out.println("USER: Error closing resources: " + e.getMessage());
            }
        }

    }

}
