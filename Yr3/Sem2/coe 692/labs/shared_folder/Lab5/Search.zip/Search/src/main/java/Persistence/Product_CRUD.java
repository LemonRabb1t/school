
package Persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Set;
import java.util.HashSet;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Helper.Product;
import java.sql.*;

/**
 *
 * @author sarahjawwad
 */
public class Product_CRUD {
    
private static Connection getCon() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/SEARCH_SNC?autoReconnect=true&useSSL=false", "root", "student123");
            System.out.println("Connection established.");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    
    
public static Set<Product> readProducts() {
    Set<Product> productsList = new HashSet<>();
    try {
        Connection con = getCon();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM SEARCH_SNC.Product");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int barcode = rs.getInt("barcode");
            String name = rs.getString("name");
            double price = rs.getDouble("price");
            Product product = new Product(barcode, name, price);
            productsList.add(product);
        }
        con.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return productsList;
}

public static Set<Product> searchForProducts(String query) {
    Set<Product> products = new HashSet<>();
    try {
        Connection con = getCon();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM SEARCH_SNC.Product WHERE name LIKE ?");
        ps.setString(1, "%" + query + "%");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int barcode = rs.getInt("barcode");
            String name = rs.getString("name");
            double price = rs.getDouble("price");
            Product product = new Product(barcode, name, price);
            products.add(product);
        }
        con.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    System.out.println(">>>>>>>>>>>>>>>>>>>>>>>" + products.size());
    return products;
}

}