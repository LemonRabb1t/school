package Business;

import Persistence.ProductADD_CRUD;

public class AddBusiness {

    public boolean addProduct(int productId, String userId) {
        return ProductADD_CRUD.addToCart(productId, userId);
    }
}
