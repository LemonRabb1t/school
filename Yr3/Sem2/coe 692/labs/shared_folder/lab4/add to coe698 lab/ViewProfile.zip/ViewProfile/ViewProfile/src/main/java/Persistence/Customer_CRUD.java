
package Persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Set;
import java.util.HashSet;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Helper.Customer;
import java.sql.*;

/**
 *
 * @author sarahjawwad
 */
public class Customer_CRUD {
    
       private static Connection getCon() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/VIEW_SNC", "root", "student123");
            System.out.println("Connection established.");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;  
    }
       
       //getting user data from the database
        public static Set<Customer> getCustomerByUsername(String username) {
        Set<Customer> customers = new HashSet<>();
        try (Connection con = getCon()) {
            if (con != null) {
                String q = "SELECT * FROM CustInfo WHERE username = ?";
                PreparedStatement ps = con.prepareStatement(q);
                ps.setString(1, username);

                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Customer customer = new Customer();
                    customer.setFname(rs.getString("firstName"));
                    customer.setLname(rs.getString("lastName"));
                    customer.setAdr(rs.getString("address"));
                    customer.setEmail(rs.getString("email"));
                    customer.setUsername(rs.getString("username"));
                    customer.setPassword(rs.getString("password"));
                    customers.add(customer);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
        }
}
