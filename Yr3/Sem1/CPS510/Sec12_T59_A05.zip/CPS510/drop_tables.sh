#!/bin/sh
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib
sqlplus64 "orclusername/password@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)
(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF
DROP TABLE customer CASCADE CONSTRAINTS;
DROP TABLE ticket_type CASCADE CONSTRAINTS;
DROP TABLE billingbooking CASCADE CONSTRAINTS;
DROP TABLE ticket_distribution CASCADE CONSTRAINTS;
DROP TABLE showinfo CASCADE CONSTRAINTS;
exit;
EOF
