#!/bin/sh
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib
sqlplus64 "orclusername/pw@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.c)
(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF


CREATE TABLE customer( 
    customer_id VARCHAR2(50) PRIMARY KEY , 
    first_name VARCHAR2(50) NOT NULL , 
    last_name VARCHAR2(50) NOT NULL , 
    email VARCHAR2(100) NOT NULL , 
    phone_no VARCHAR2(30) NOT NULL, 
    DOB VARCHAR2(20) NOT NULL, --yyyymmdd 
    gender VARCHAR2(1) NOT NULL);

CREATE TABLE ticket_type ( 
    ticket_id VARCHAR2(10) PRIMARY KEY, 
    ticket_number VARCHAR2(10) NOT NULL, 
    ticket_class VARCHAR2(100) NOT NULL, 
    section_number VARCHAR2(10) NOT NULL, 
    seat_number VARCHAR2(10) NOT NULL, 
    show_name VARCHAR2(500) NOT NULL, 
    show_time_date VARCHAR2(100) NOT NULL 
);

CREATE TABLE billingbooking ( 
    billing_id VARCHAR(20) PRIMARY KEY, 
    booking_id VARCHAR2(20) NOT NULL, 
    bill_date VARCHAR2(11) NOT NULL, 
    status VARCHAR2(10) NOT NULL, 
    service_fee VARCHAR2(10) NOT NULL, 
    tax VARCHAR2(10) NOT NULL, 
    total VARCHAR2(10) NOT NULL, 
    payment_type VARCHAR2(30) NOT NULL, --Credit/Deb 
    payment_comp VARCHAR2(30) NOT NULL, -- mastercard, visa, interact 
    ticket_id VARCHAR(10) NOT NULL 
);

CREATE TABLE showinfo ( 
    show_id VARCHAR2(10) PRIMARY KEY , 
    show_title VARCHAR2(100) NOT NULL, 
    artist_performers VARCHAR2(50) NOT NULL, 
    location VARCHAR2(50) NOT NULL, 
    all_show_times_dates VARCHAR2(40) NOT NULL, 
    show_description VARCHAR2(100) NOT NULL, 
    available_ticket_classes VARCHAR2(40) NOT NULL 
);

CREATE TABLE ticket_distribution ( 
    distribution_reciept VARCHAR2(10) PRIMARY KEY , 
    ticket_id VARCHAR2(10) , 
    customer_fname VARCHAR2(50) , 
    customer_lname VARCHAR2(50) NOT NULL, 
    customer_email VARCHAR2(50) NOT NULL, 
    customer_phone_no VARCHAR2(10) NOT NULL, 
    show_time_date VARCHAR2(40) NOT NULL, 
    location VARCHAR2(50) NOT NULL, 
    FOREIGN KEY (ticket_id) REFERENCES ticket_type(ticket_id) 
);

CREATE TABLE ticket_restriction ( 
    restriction_id VARCHAR2(10) PRIMARY KEY , 
    ticket_id VARCHAR2(10) , 
    show_id VARCHAR2(10) NOT NULL, 
    reason_for_restriction VARCHAR2(500) NOT NULL, 
    FOREIGN KEY (ticket_id) REFERENCES ticket_type(ticket_id) 
);

exit;
EOF
