#!/bin/sh
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib
sqlplus64 "orclusername/password@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

-- same show info and ticket rest show ID
SELECT showinfo.show_id, showinfo.show_title,showinfo.artist_performers, ticket_restriction.restriction_id, ticket_restriction.ticket_id
FROM showinfo
INNER JOIN ticket_restriction ON ticket_restriction.show_id = showinfo.show_id
ORDER BY showinfo.show_id;

CREATE VIEW ticket_pricing AS
SELECT b.billing_id,  b.total, t.ticket_id, t.show_name
FROM billingbooking b
JOIN ticket_type t ON t.ticket_id = b.ticket_id;

SELECT *
FROM ticket_pricing;


(SELECT *
FROM billingbooking)
MINUS
(SELECT *
FROM  billingbooking b
WHERE payment_type = "Credit");


SELECT *
FROM showinfo
WHERE artist_performers LIKE 'T%'
OR
artist_performers LIKE 'G%';

SELECT customer_fname, customer_lname, location
FROM ticket_distribution
GROUP BY location;

exit;
EOF
